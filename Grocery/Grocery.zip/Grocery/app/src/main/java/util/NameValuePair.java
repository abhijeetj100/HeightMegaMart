package util;

/**
 * Created by Rajesh Dabhi on 28/6/2017.
 */

public class NameValuePair {
    public String name, value;

    public NameValuePair(String _name, String _value) {
        name = _name;
        value = _value;
    }
}
